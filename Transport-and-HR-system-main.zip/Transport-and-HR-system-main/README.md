HR diagram
![image](https://github.com/LinoyBitan/Transport-and-HR-system/assets/127621723/1016abb5-bd8c-4d54-aee3-c7ca17b9e846)
