package BuisnessLayer.TransportManager;

/**
 * This enumeration represents the type of a truck, whether they are moving Dry, Cooler or Freezer cargo.
 */

public enum TruckType {

    DryTruck, CoolerTruck, FreezerTruck;
}
