package BuisnessLayer.TransportManager;

public enum DocumentStatus {
    waiting, inProgress, finished
}
