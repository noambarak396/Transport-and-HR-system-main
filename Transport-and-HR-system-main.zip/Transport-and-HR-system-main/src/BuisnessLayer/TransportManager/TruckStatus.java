package BuisnessLayer.TransportManager;

/**
 * This enumeration represents the status of a truck, whether they are available or not available.
 */

public enum TruckStatus {

    Available, NotAvailable;
}
