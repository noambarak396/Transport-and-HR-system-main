package BuisnessLayer.HR;

public enum JobType {
    STOREKEEPER,
    CASHIER,
    SHIFT_MANAGER,
    GENERAL_EMPLOYEE,
    SECURITY,
    USHER,
    CLEANER
}
