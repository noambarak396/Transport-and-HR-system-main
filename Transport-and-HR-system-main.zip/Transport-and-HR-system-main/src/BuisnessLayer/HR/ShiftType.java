package BuisnessLayer.HR;

public enum ShiftType {
    EVENING,
    MORNING
}
